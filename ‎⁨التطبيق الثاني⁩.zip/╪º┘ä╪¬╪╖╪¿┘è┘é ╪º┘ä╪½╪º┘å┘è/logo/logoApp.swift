//
//  logoApp.swift
//  logo
//
//  Created by Rana on 19/05/1444 AH.
//

import SwiftUI

@main
struct logoApp: App {
    var body: some Scene {
        WindowGroup {
            Logo()
        }
    }
}
